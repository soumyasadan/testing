@extends('frontEnd.layout')
@section('content')
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<link href="{{ URL::asset('assets/frontend/reservation/css/animate.min.css')}}" rel="stylesheet" media="all">

<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link href="{{ asset("assets/dashboard/js/iconpicker/fontawesome-iconpicker.min.css") }}" rel="stylesheet">


<link href="{{ URL::asset('assets/frontend/reservation/css/style.css')}}" rel="stylesheet" type="text/css">

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">

<link href="{{ URL::asset('assets/frontend/reservation/imgs/favicon.png')}}" rel="shortcut icon" type="image/png">

@php
    $months = array(1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun', 7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec');
@endphp

<?php 

if(empty($booking)){ ?><script type="text/javascript">
    window.location.href='/airportexpress/site/home/reservation';exit;
</script><?php }
else { ?>
<section class="section_check">

<div class="container">

<div class="row">

  <div class="col-lg-12 col-md-12 col-12">

    <div class="begin_main">

      <h2>Cart</h2>
      <?php //echo '<pre>';print_r($zip_all); exit;?>
      <table style="width:100%"><tr><td align="left" style="font-size: initial;padding:10px">Product</td>
      <td align="left"  style="font-size: initial;padding:10px">Quantity</td>
      <td  align="left"  style="font-size: initial;padding:10px">Price</td>
      <td  align="left"  style="font-size: initial;padding:10px">Amount</td></tr>
      <tr><td style="font-size: 15px;padding:10px">Airport : {{$booking->airport}}<br>
      Trip type : @if($booking->triptype=='to') Departure  @else Arrival @endif<br>
      @if($booking->zipcode_id=='')
      Hotel : {{$hotel_name}}<br>
      @else 
      Zipcode :<?php echo $zip_all->zipcode_name;?><br>
      @endif
      Airline/Flight : {{$booking->airline}}<br>
      @if($booking->triptype=='to') Departure date @else Arrival Date @endif : {{$booking->pickup_Date}}<br>
      @if($booking->triptype=='to') Departure Time @else Arrival Time @endif : {{$booking->pickup_time}}<br>
      @if($booking->return_trip=='1') Return Date : {{$booking->r_pick_up_date}} <br>
      Return Time : {{$booking->r_pick_up_time}}  @endif
      </td> 
      
      <td style="font-size: 15px;padding:10px">Adult : {{$booking->no_of_adult}}<br>
      @if($booking->no_of_children!='')  Children : {{$booking->no_of_children}} @endif</td>
      
      <td style="font-size: 15px;padding:10px">
        @if($booking->affiliate_id=='') <?php /* not an affiliate*/?>
        @if($master_prices->hotel_id==0 && $booking->zipcode_id=='') <?php /* not an affiliate and no zipcode */ ?>
       <?php  if($booking->return_trip==0){ 
         
          if($booking->airport=='San Francisco (SFO)'){ echo $price= $masterprice->sf_adult_one_way;}
          
          elseif($booking->airport=='Oakland (OAK)'){ echo $price= $masterprice->oakland_adult_arrival;}
          
          else { echo $price= $masterprice->sjc_adult_one_way;}
          
          } else {
             
          if($booking->airport=='San Francisco (SFO)'){ echo $price= $masterprice->sf_adult_round_trip;}
          
          elseif($booking->airport=='Oakland (OAK)'){ echo $price= $masterprice->oakland_adult_roundup;}
          
          else { echo $price= $masterprice->sjc_adult_round_trip;}
          
          }
        ?>
        <br>
        @if($booking->no_of_children!='')      <?php /* have children*/?>
        <?php if($booking->return_trip==0){
          if($booking->airport=='San Francisco (SFO)'){  echo $price_c= $masterprice->sf_child_one_way;}
          
          elseif($booking->airport=='Oakland (OAK)'){ echo $price_c= $masterprice->oakland_additional_adult;}
          
          else { echo $price_c= $masterprice->sjc_child_one_way;}
          }
          else {
          if($booking->airport=='San Francisco (SFO)'){ echo $price_c= $masterprice->sf_child_round_way;}
          
          elseif($booking->airport=='Oakland (OAK)'){ echo $price_c= $masterprice->oakland_additional_person_round_up;}
          
          else { echo $price_c= $masterprice->sjc_child_round_way;}
          }
          ?>
        @endif                                     <?php /* end have children*/?>
        @else
        <?php
      
      if($booking->return_trip==0){ 
      if($booking->airport=='San Francisco (SFO)'){ echo  $price= $zip_all->sf_adult_one_way;}
      
      elseif($booking->airport=='Oakland (OAK)'){ echo $price= $zip_all->oakland_adult_arrival;}
      
      else { echo $price= $zip_all->sjc_adult_one_way;}
      
      } else {
         
      if($booking->airport=='San Francisco (SFO)'){ echo  $price= $zip_all->sf_adult_round_trip;}
      
      elseif($booking->airport=='Oakland (OAK)'){ echo  $price= $zip_all->oakland_adult_roundup;}
      
      else { echo  $price= $zip_all->sjc_adult_round_trip;}
      
      }?><br>
      @if($booking->no_of_children!='') <?php if($booking->return_trip==0){
      if($booking->airport=='San Francisco (SFO)'){  echo $price_c= $zip_all->sf_child_one_way;}
      
      elseif($booking->airport=='Oakland (OAK)'){ echo $price_c= $zip_all->oakland_additional_adult;}
      
      else { echo  $price_c= $zip_all->sjc_child_one_way;}
      }
      else {
      if($booking->airport=='San Francisco (SFO)'){ echo  $price_c= $zip_all->sf_child_round_way;}
      
      elseif($booking->airport=='Oakland (OAK)'){ echo $price_c= $zip_all->oakland_additional_person_round_up;}
      
      else {  echo  $price_c= $zip_all->sjc_child_round_way;}
      }
      ?>
         @endif 
         @else 
         <?php
      
         if($booking->return_trip==0){ 
         if($booking->airport=='San Francisco (SFO)'){ echo  $price= $master_prices->sf_adult_one_way;}
         
         elseif($booking->airport=='Oakland (OAK)'){ echo $price= $master_prices->oakland_adult_arrival;}
         
         else { echo $price= $master_prices->sjc_adult_one_way;}
         
         } else {
            
         if($booking->airport=='San Francisco (SFO)'){ echo  $price= $master_prices->sf_adult_round_trip;}
         
         elseif($booking->airport=='Oakland (OAK)'){ echo  $price= $master_prices->oakland_adult_roundup;}
         
         else { echo  $price= $master_prices->sjc_adult_round_trip;}
         
         }?><br>
         @if($booking->no_of_children!='') <?php if($booking->return_trip==0){
         if($booking->airport=='San Francisco (SFO)'){  echo $price_c= $master_prices->sf_child_one_way;}
         
         elseif($booking->airport=='Oakland (OAK)'){ echo $price_c= $master_prices->oakland_additional_adult;}
         
         else { echo  $price_c= $master_prices->sjc_child_one_way;}
         }
         else {
         if($booking->airport=='San Francisco (SFO)'){ echo  $price_c= $master_prices->sf_child_round_way;}
         
         elseif($booking->airport=='Oakland (OAK)'){ echo $price_c= $master_prices->oakland_additional_person_round_up;}
         
         else {  echo  $price_c= $master_prices->sjc_child_round_way;}
         }
         ?>
        @endif
      </td>
      
      <td style="font-size: 15px;padding:10px">
     @if($booking->no_of_children=='') 
         <?php 
        $cou_a=$booking->no_of_adult;
        $adult_total=$price*$cou_a;
        echo $adult_total;  
        $total=$adult_total;
        ?>
        @else
         <?php 
        $cou_a=$booking->no_of_adult;
        $adult_total=$price*$cou_a;
        $cou_c=$booking->no_of_children;
        $child_total=$price_c*$cou_c;
        echo $adult_total; echo '<br>';echo $child_total; 
        $total=$child_total+$adult_total;
        ?>
        @endif?>
       </td>
                       </tr>
                      <tr style="border-top: 1px solid #8695b1;"><td colspan="2" style="font-size: 15px;padding:10px">All Prices are in Dollars</td>
                       <td style="font-size: 15px;padding:10px">Total</td><td style="font-size: 15px;padding:10px">
                        <?php  echo $total; ?>
                       </td></tr>
                       
                       
        <tr style="border-top: 1px solid #8695b1;"><td colspan="3" style="font-size: 15px;padding:10px"></td>
        <td style="font-size: 15px;padding:10px;text-align: right;">
            <a href="{{ route('HomePage').'/reservation/' }}" class="edit_reser" >Edit</a>                       </td></tr>               
                       
      </table>
      
</div>


       <div class="begin_main">

      <h2>Checkout</h2>
        {{Form::open(['route'=>['reservationaddtocart'],'method'=>'POST', 'files' => true,'id' => 'cart_add' ])}}
                              <input type="hidden" value="<?php echo $total; ?>" name="total"> 

<input type="hidden" name="reservation_id" value="{{$booking->id}}">
<div class="col-sm-12 col-md-12 col-lg-6 first">
<label class="control-label " for="first_name"  style="font-size: 15px;font-weight: normal;padding: 10px 0;">First Name</label>
<input type="text" id="first_name" name="first_name" class="form-control" placeholder="First Name">
<div id="err_first_name" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second">
<label class="control-label " for="lastname" style="font-size: 15px;font-weight: normal;padding: 10px 0;">Last Name</label>
<input placeholder="Last Name" class="form-control date-time" id="lastname" name="lastname" type="text" value="">
<div id="err_lastname" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second">
<label class="control-label " for="company"  style="font-size: 15px;font-weight: normal;padding: 10px 0;">Company</label>
<input placeholder="Company" class="form-control date-time" id="company" name="company" type="text" value="">
<div id="err_company" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second">
<label class="control-label " for="address"  style="font-size: 15px;font-weight: normal;padding: 10px 0;">Address</label>
<input placeholder="Address" class="form-control date-time" id="address" name="address" type="text" value="">
<div id="err_address" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second">
<label class="control-label " for="city"  style="font-size: 15px;font-weight: normal;padding: 10px 0;">City</label>
<input placeholder="City" class="form-control date-time" id="city" name="city" type="text" value="">
<div id="err_city" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second">
<label class="control-label " for="state"  style="font-size: 15px;font-weight: normal;padding: 10px 0;">State</label>
<input placeholder="State" class="form-control date-time" id="state" name="state" type="text" value="">
<div id="err_state" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second">
<label class="control-label " for="country"  style="font-size: 15px;font-weight: normal;padding: 10px 0;">Country</label>
<input placeholder="Country" class="form-control date-time" id="country" name="country" type="text" value="">
<div id="err_country" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second">
<label class="control-label " for="zip_code"  style="font-size: 15px;font-weight: normal;padding: 10px 0;">Zip Code</label>
<input placeholder="Zip Code" class="form-control date-time" id="zip_code" name="zip_code" type="text" value="">
<div id="err_zip_code" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second">
<label class="control-label " for="cell_phone"  style="font-size: 15px;font-weight: normal;padding: 10px 0;">Cell Phone</label>
{!! Form::number('cell','', array('placeholder' =>'Cell Phone','class' => 'form-control date-time','id'=>'cell_phone')) !!}
<div id="err_cell_phone" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second">
<label class="control-label " for="fax"  style="font-size: 15px;font-weight: normal;padding: 10px 0;">fax</label>
<input placeholder="Fax" class="form-control date-time" id="fax" name="fax" type="text" value="">
<div id="err_fax" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second" style="margin: 0 0 10px 0;">
<label class="control-label " for="email"  style="font-size: 15px;font-weight: normal;padding: 10px 0;">Email</label>
<input placeholder="Email" class="form-control date-time" id="email" name="email" type="email" value="">
<div id="err_email" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second" style="margin: 0 0 10px 0;">
<label class="control-label " for="amount"  style="font-size: 15px;font-weight: normal;padding: 10px 0;">Amount</label>
<input placeholder="Amount" class="form-control date-time"  type="text" value="<?php echo $total; ?>" disabled>
<input  name="amount"  type="hidden" value="<?php echo $total; ?>" >
<div id="err_amount" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second" style="margin: 0 0 10px 0;">
<label class="control-label " for="name_on_card"  style="font-size: 15px;font-weight: normal;padding: 10px 0;">Card Holder</label>
<input placeholder="Card Holder" type="text" class="form-control" id="owner" name="owner" value="{{ old('owner') }}" required>
<div id="err_name_on_card" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second" style="margin: 0 0 10px 0;">
<label class="control-label " for="cardNumber"  style="font-size: 15px;font-weight: normal;padding: 10px 0;">Card Number</label>
{!! Form::number('cardNumber','', array('placeholder' =>'Card Number','class' => 'form-control date-time','id'=>'cardNumber','minlength'=>'14','maxlength'=>'16','min'=>'0')) !!}
<div id="err_cardNumber" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second" style="margin: 0 0 10px 0;">
<label class="control-label " for="cvv"  style="font-size: 15px;font-weight: normal;padding: 10px 0;">CVV</label>
{!! Form::number('cvv','', array('placeholder' =>'CVV','maxlength'=>"3",'class' => 'form-control date-time','id'=>'cvv','minlength'=>'3','maxlength'=>'4','min'=>'0')) !!}
<div id="err_cvv" style="position: absolute;"></div>
</div>
<div class="col-sm-12 col-md-12 col-lg-6 second" style="margin: 0 0 10px 0;">
<label class="control-label " for="cvv"  style="font-size: 15px;font-weight: normal;padding: 10px 0;width:100%">Date</label>
<select class="form-control" id="expiration-month" name="expiration-month" style="float: left; width: 100px; margin-right: 10px;">
@foreach($months as $k=>$v)
<option value="{{ $k }}" {{ old('expiration-month') == $k ? 'selected' : '' }}>{{ $v }}</option>                                                        
@endforeach
</select> 
<select class="form-control" id="expiration-year" name="expiration-year"  style="float: left; width: 100px;">                                                 
@for($i = date('Y'); $i <= (date('Y') + 15); $i++)
<option value="{{ $i }}">{{ $i }}</option>            
@endfor
</select><div id="err_cvv" style="position: absolute;"></div>
</div>
                                                
                                              
<div class="form-group btn_new">
<div class=" col-sm-12">
<button type="submit" class="btn_submit">Submit</button>
</div>
</div>
{{Form::close()}}
</div>



</div>
</div>
</div>
</section>
<?php } ?>

<style>.custom-control-input{ 
position:initial !important;opacity:1 !important;
}
#myInput{
    background-image: url(https://seowebdesign.in/airportexpress/site/uploads/banners/searchicon.png);
    background-repeat: no-repeat;
    background-position: right;

}
.edit_reser{
     background: #ce182f;
    padding: 5px 10px;
    color: white;
    text-decoration: none;
}
</style>


<link href="https://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" rel="Stylesheet">

 
@endsection